import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json({ limit: '10mb' }));

// 多米 API 基础配置
const DUOMI_API_BASE = 'https://duomiapi.com';
const DUOMI_API_KEY = process.env.DUOMI_API_KEY || '';

// ──────────────────────────────────────────────
// Helper: 调用多米 API
// ──────────────────────────────────────────────
async function duomiRequest(path: string, body: Record<string, unknown>) {
  const url = `${DUOMI_API_BASE}${path}`;
  const resp = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'key': DUOMI_API_KEY,
    },
    body: JSON.stringify(body),
  });
  return await resp.json() as Record<string, unknown>;
}

// ──────────────────────────────────────────────
// Health check
// ──────────────────────────────────────────────
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    provider: 'duomiapi.com',
    hasKey: !!DUOMI_API_KEY,
  });
});

// ──────────────────────────────────────────────
// POST /api/images/generate
// 提交图片生成任务，返回 taskId
// ──────────────────────────────────────────────
app.post('/api/images/generate', async (req, res) => {
  const {
    prompt,
    model = 'gemini-3.1-flash-image-preview',
    size,
    n = 1,
    quality = 'high',
    style,
    response_format,
    user,
  } = req.body as Record<string, unknown>;

  if (!prompt) {
    return res.status(400).json({
      error: { message: 'prompt is required', type: 'invalid_request_error' }
    });
  }

  if (!DUOMI_API_KEY) {
    return res.status(500).json({
      error: { message: 'DUOMI_API_KEY not configured', type: 'server_error' }
    });
  }

  try {
    // 构建多米 API 参数
    const duomiBody: Record<string, unknown> = {
      prompt: String(prompt),
      model: String(model),
      n: Number(n) || 1,
      quality: String(quality),
    };

    // size 字段：多米支持 1K/2K/4K 或具体尺寸
    if (size) {
      duomiBody.size = String(size);
    }

    if (style) {
      duomiBody.style = String(style);
    }

    const data = await duomiRequest('/api/gemini/nano-banana', duomiBody) as Record<string, unknown>;

    if (data.code !== 200) {
      return res.status(400).json({
        error: { message: data.msg || '提交失败', type: 'api_error' }
      });
    }

    const taskId = (data.data as Record<string, unknown>)?.task_id as string;
    res.json({ taskId });
  } catch (err) {
    console.error('[/api/images/generate]', err);
    res.status(500).json({
      error: { message: 'Internal server error', type: 'server_error' }
    });
  }
});

// ──────────────────────────────────────────────
// GET /api/images/task/:taskId
// 轮询任务状态
// ──────────────────────────────────────────────
app.get('/api/images/task/:taskId', async (req, res) => {
  const { taskId } = req.params;

  if (!taskId) {
    return res.status(400).json({ error: { message: 'taskId required' } });
  }

  if (!DUOMI_API_KEY) {
    return res.status(500).json({ error: { message: 'DUOMI_API_KEY not configured' } });
  }

  try {
    const data = await duomiRequest('/api/gemini/nano-banana/status', { id: taskId }) as Record<string, unknown>;

    if (data.code !== 200) {
      return res.status(400).json({
        error: { message: data.msg || '查询失败' }
      });
    }

    const taskData = data.data as Record<string, unknown>;
    const status = String(taskData.status); // "0"=pending "1"=running "3"=succeeded "2"=failed
    const stateMap: Record<string, string> = {
      '0': 'pending',
      '1': 'running',
      '2': 'failed',
      '3': 'succeeded',
    };

    const state = stateMap[status] || 'pending';
    let images: string[] = [];

    if (state === 'succeeded') {
      const innerData = taskData.data as Record<string, unknown> | null;
      if (innerData?.images && Array.isArray(innerData.images)) {
        images = (innerData.images as Record<string, unknown>[]).map(img => String(img.url));
      }
    }

    res.json({
      state,
      taskId,
      images,
      msg: taskData.msg || '',
    });
  } catch (err) {
    console.error('[/api/images/task/:taskId]', err);
    res.status(500).json({ error: { message: 'Internal server error' } });
  }
});

// ──────────────────────────────────────────────
// POST /api/images/task/:taskId/refresh
// 同上，但用 POST 方法兼容不同客户端
// ──────────────────────────────────────────────
app.post('/api/images/task/:taskId/refresh', (req, res) => {
  req.url = `/api/images/task/${req.params.taskId}`;
  app._router!.handle(req, res);
});

app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`📡 Health check: http://localhost:${PORT}/api/health`);
  console.log(`🔗 API Provider: duomiapi.com`);
  console.log(`🔑 API Key configured: ${DUOMI_API_KEY ? 'YES' : 'NO ⚠️'}`);
});
